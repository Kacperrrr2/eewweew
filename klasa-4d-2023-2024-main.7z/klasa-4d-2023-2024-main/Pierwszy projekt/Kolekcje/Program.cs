﻿using System;

namespace Kolekcje
{
    class Program
    {
        static void Main(string[] args)
        {
            TestKolekcji testKolekcji = new TestKolekcji();
            //testKolekcji.TestTablic();
            testKolekcji.TestTablicObiekty();
        }
    }
}
