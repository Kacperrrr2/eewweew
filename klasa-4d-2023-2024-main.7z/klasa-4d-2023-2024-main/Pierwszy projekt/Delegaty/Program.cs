﻿using System;

namespace Delegaty
{
    class Program
    {
        static void Main(string[] args)
        {
            TestDelegat testDelegat = new TestDelegat();
            testDelegat.Test();

            Console.ReadLine();
        }
    }
}
