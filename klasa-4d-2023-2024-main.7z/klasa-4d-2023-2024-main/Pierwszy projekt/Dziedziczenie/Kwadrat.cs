﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dziedziczenie
{
    class Kwadrat : Prostakat
    {
        public Kwadrat(string n, float a) : base(n, a, a)
        {

        }
    }
}
