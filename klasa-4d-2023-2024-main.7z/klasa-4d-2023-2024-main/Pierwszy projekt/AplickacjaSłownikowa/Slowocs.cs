﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AplickacjaSłownikowa
{
    class Slowocs
    {
        public string Slowoo { get; set; }
        public string Nameee { get; set; }
    }
}
