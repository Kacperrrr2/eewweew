﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComboboxWpfApp
{
    public class OwnColor
    {
        public string NameOfColor_Pol { get; set; }
        public string NameOfColor_Eng { get; set; }
    }
}
