# klasa-4d-2022-2023


Komputery 1, 3, 5, 7, 9, 11, 13, 15, 17

https://forms.office.com/e/zFaV1JqhUV

Komputery 2, 4, 6, 8, 10, 12, 14, 16

https://forms.office.com/e/xcHJ8Z5uu8
